import './App.css';
import UserManagement from './components/UserManagement';

function App() {
  return (
    <>
      <UserManagement />
    </>
  );
}

export default App;
